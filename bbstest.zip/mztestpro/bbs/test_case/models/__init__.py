# coding=utf-8
import os

print(os.path.dirname(__file__))              #F:/jichu/mztestpro/bbs/test_case/models
print(os.path.dirname(os.path.dirname(__file__)))       #F:/jichu/mztestpro/bbs/test_case
print(str('F:/jichu/mztestpro/bbs/test_case'))